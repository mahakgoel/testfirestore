package com.example.mahak.testfirestoreapplication

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.design.widget.TextInputEditText
import android.support.design.widget.TextInputLayout
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore

import kotlinx.android.synthetic.main.activity_main.*
import java.nio.file.Files.exists
import com.google.firebase.firestore.DocumentSnapshot
import com.google.android.gms.tasks.Task
import android.support.annotation.NonNull
import com.google.android.gms.tasks.OnCompleteListener
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    lateinit var db: DocumentReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        val store = findViewById<View>(R.id.storeBtn) as Button
        store.setOnClickListener { view: View? -> store () }


    }

    private fun store () {
        val input1Txt = findViewById<View>(R.id.input1Text) as TextInputEditText
        val input2Txt = findViewById<View>(R.id.input2Text) as TextInputEditText
        val input3Txt = findViewById<View>(R.id.input3Text) as TextInputEditText


        val items = HashMap<String, Any>()
        items.put("Input1", input1Txt.getText().toString())
        items.put("Input2", input2Txt.getText().toString())
        items.put("Input3", input3Txt.getText().toString())

        val db = FirebaseFirestore.getInstance().document("Test/data")

        db.set(items).addOnSuccessListener {
            void: Void? -> Toast.makeText(this, "Successfully uploaded to the database :)", Toast.LENGTH_LONG).show()
        }.addOnFailureListener { exception: java.lang.Exception ->
            Toast.makeText(this, exception.toString(), Toast.LENGTH_LONG).show()
        }


        // HERE I'M TRYING TO READ FROM FIRESTORE AND IT'S NOT WORKING
        val printView = findViewById(R.id.printView) as TextView
        val docRef = db.collection("Test").document("data")
        docRef.get().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val document = task.result
                if (document.exists()) {
                    println(document.data!!.toString())
                } else {
                    println("No such doc")
                }
            } else {
                println("Failed task")
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
